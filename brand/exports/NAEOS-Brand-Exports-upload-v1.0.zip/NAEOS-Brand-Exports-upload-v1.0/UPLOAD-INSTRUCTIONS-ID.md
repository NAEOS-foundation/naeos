# NAEOS Brand Exports v1.0 — Upload

Paket ini berisi 37 file dari tiga paket hasil ekstraksi. Letakkan ketiga folder paket langsung di `brand/exports/` pada repository `NAEOS-foundation/naeos`.

## Isi
- `NAEOS-Logo-Exports-v1.0/` — 6 file
- `NAEOS-Logo-System-v1.0/` — 24 file (turunan/historis; bukan pengganti master v2.0.0)
- `NAEOS-Social-Avatar-v1.0/` — 7 file

## Cara menerapkan pada branch PR
Jalankan dari PowerShell setelah clone repository:

```powershell
git switch docs/brand-guidelines-v1
git pull --ff-only origin docs/brand-guidelines-v1
$source = "C:\PATH\TO\NAEOS-Brand-Exports-upload-v1.0"
New-Item -ItemType Directory -Force brand/exports | Out-Null
Copy-Item "$source\NAEOS-Logo-Exports-v1.0" brand/exports/ -Recurse -Force
Copy-Item "$source\NAEOS-Logo-System-v1.0" brand/exports/ -Recurse -Force
Copy-Item "$source\NAEOS-Social-Avatar-v1.0" brand/exports/ -Recurse -Force
git status --short
git add brand/exports/NAEOS-Logo-Exports-v1.0 brand/exports/NAEOS-Logo-System-v1.0 brand/exports/NAEOS-Social-Avatar-v1.0
git commit -s -m "chore(brand): add extracted logo and avatar exports"
git push origin docs/brand-guidelines-v1
```

`-s` menambahkan DCO sign-off menggunakan identitas Git yang sudah dikonfigurasi. Pastikan `git config user.name` dan `git config user.email` sesuai identitas kontributor sebelum commit.

Setelah push, PR #825 akan menerima commit baru secara otomatis. Jangan merge sebelum pemeriksaan CI, DCO, dan security selesai.
