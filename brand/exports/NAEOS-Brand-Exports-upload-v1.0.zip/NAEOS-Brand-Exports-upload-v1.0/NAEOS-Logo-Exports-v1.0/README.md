# NAEOS Logo Exports v1.0

Source: NAEOS Primary Symbol Master v2.0.0
Canonical source: `NAEOS-foundation/naeos/brand/master/naeos-primary-symbol-master-v2.svg`

Includes the SVG source copy and transparent PNG exports at 512, 1024, and 2048 px wide. The original 260:165 aspect ratio is preserved. All exports are derivatives; do not edit the canonical master or alter the mark geometry, proportions, or approved gradients.
