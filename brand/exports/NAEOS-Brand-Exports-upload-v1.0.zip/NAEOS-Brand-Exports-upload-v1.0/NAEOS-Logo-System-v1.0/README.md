# NAEOS Logo System v1.0

Status: Approved master symbol direction; production variants derived from the approved Candidate v1.0 geometry.

## Included
- `primary-gradient.svg/png`: gradient master appearance
- `primary-flat.svg/png`: white + Signal Blue flat version
- `monochrome-white.svg/png`, `monochrome-black.svg/png`, `monochrome-signal-blue.svg/png`
- `app-icon-*.png`: rounded-square app icon backgrounds at 1024 and 512 px
- `favicon-*.png` and `favicon.ico`
- `logo-system-contact-sheet.jpg`: visual overview

## Brand colors from NAEOS Brand Identity v3.1
- Obsidian: `#0B0F19`
- Signal Blue: `#2563FF`
- Ion Blue: `#60A5FA`
- Mist: `#E5E7EB`
- Cloud White: `#FFFFFF`

## Important
All variants reuse the exact two vector path geometries from the approved Candidate v1.0 SVG. Only fills/background treatments change. No geometric redesign was performed.

The source Candidate v1.0 remains preserved separately as `naeos-primary-symbol-master-candidate-v1.svg`.
