# NAEOS Social Avatar v1.0

- Source artwork: NAEOS Primary Symbol Master v2.0 export.
- Symbol geometry was not redrawn or altered; the artwork was scaled proportionally.
- Background: Deep Navy (#0B0F19) with a restrained blue glow and subtle cyan-blue circular keyline.
- Exports: 1024, 512, 320, 180, and 64 px square PNG.
- Intended use: social profile avatars and compact brand placements.
